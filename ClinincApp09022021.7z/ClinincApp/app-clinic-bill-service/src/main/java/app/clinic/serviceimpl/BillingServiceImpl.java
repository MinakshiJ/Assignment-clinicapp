package app.clinic.serviceimpl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jvnet.hk2.annotations.Service;
import org.springframework.beans.factory.annotation.Autowired;

import app.clinic.dto.BillingDTO;
import app.clinic.model.Biling;
import app.clinic.repository.BilingRepository;
import app.clinic.service.BilingService;

@Service
public class BillingServiceImpl implements BilingService {

	private static final Logger LOG = LogManager.getLogger(BillingServiceImpl.class);

	@Autowired
	BilingRepository bilingRepository;

	@Override
	public String createBiling(BillingDTO billingDTO) {
		LOG.info("<<<LOG ENTRY>>" + BillingServiceImpl.class + "createBiling()");
		Biling bill=saveBilling(billingDTO);
		if(bill!=null)
			return "success";
		else 
			return "failure";
	
	}

	private Biling saveBilling(BillingDTO billingDTO) {
		
		Biling bill = new Biling();
		bill.setPatient_ID(billingDTO.getPatiendId());
		bill.setPhysicIan_ID(billingDTO.getPhysicianId());
		bill.setBilledTs(java.util.Calendar.getInstance().getTime());

		return bilingRepository.save(bill);
		
	}

}
