package app.clinic.service;

import app.clinic.dto.BillingDTO;

public interface BilingService {

	String createBiling(BillingDTO billing);
}
