package app.clinic.rest.conversation;


	import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import app.clinic.dto.BillingDTO;
import app.clinic.serviceimpl.BillingServiceImpl;
	
	@RestController
	@RequestMapping("service/billing")
	public class BillingController {

		@Autowired
		BillingServiceImpl billingServiceImpl;


		@PostMapping("/createNewBilling")
		public ResponseEntity<String> createNewIntent(@RequestBody BillingDTO billingDTO) {

			String response = billingServiceImpl.createBiling(billingDTO);
			//JsonObject jsonobj = new JsonParser().parse(response).getAsJsonObject();
			//if (jsonobj.get("status").getAsString().equals("200")) {
			if(response.equals("response")) {
				return ResponseEntity.status(HttpStatus.OK).body(response);
			} else
			{
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
			}
		}

}
