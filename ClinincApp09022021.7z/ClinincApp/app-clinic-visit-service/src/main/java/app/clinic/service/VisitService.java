package app.clinic.service;

import app.clinic.dto.VisitDTO;

public interface VisitService {

	String createVisit(VisitDTO visitDTO);

}
