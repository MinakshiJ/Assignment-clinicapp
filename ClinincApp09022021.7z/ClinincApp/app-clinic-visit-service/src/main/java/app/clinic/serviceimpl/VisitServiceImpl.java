package app.clinic.serviceimpl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import app.clinic.dto.VisitDTO;
import app.clinic.exception.DuplicateDataException;
import app.clinic.exception.HolidayException;
import app.clinic.model.Holiday;
import app.clinic.model.Patient;
import app.clinic.model.Physician;
import app.clinic.model.Visit;
import app.clinic.repository.HolidayRepository;
import app.clinic.repository.PatientRepository;
import app.clinic.repository.PhysicianRepository;
import app.clinic.repository.VisitRepository;
import app.clinic.service.VisitService;
import app.clinic.util.ClinicCommonUtil;


public class VisitServiceImpl implements VisitService {

	@Autowired
	PatientRepository patientRepository;

	@Autowired
	PhysicianRepository physicianRepository;

	@Autowired
	VisitRepository visitRepository;

	@Autowired
	HolidayRepository holidayRepository;

	private static final Logger LOG = LogManager.getLogger(VisitServiceImpl.class);

	@Override
	public String createVisit(VisitDTO visitDTO) {
		String msg = "failure";
		LOG.info("<<<LOG ENTRY>>" + VisitServiceImpl.class + "createVisit()");
		try {
			Visit visit = saveVisit(visitDTO);
			
			if (visit != null) {
				LOG.info("<<<LOG EXIT>>" + VisitServiceImpl.class + "createVisit()");
				msg = "success";
			} else {
				LOG.info("<<<LOG EXIT>>" + VisitServiceImpl.class + "createVisit()");
				msg = "failure";
			}
		} catch (Exception e) {

			LOG.info("<<<LOG Exception>>" + VisitServiceImpl.class + "createVisit()" + e.getMessage());
		}
		return msg;

	}

	private Visit saveVisit(VisitDTO visitDTO) throws DuplicateDataException, HolidayException {
		LOG.info("<<<LOG ENTRY>>" + VisitServiceImpl.class + "saveVisit()");

		Holiday holiday = new Holiday();
		Visit visit = new Visit();
		holiday.setHoliday(visitDTO.getVisitDateTime());
		if (holidayRepository.findAllByHoliday(visitDTO.getVisitDateTime()) != null)
			throw new HolidayException("Visit Can not be on Holiday");
		{
			savePatientDtl(visitDTO);
			savePhysicianDtl(visitDTO);
			visit = saveVisitDtl(visitDTO);
		}
		LOG.info("<<<LOG EXIT>>" + VisitServiceImpl.class + "saveVisit()");
		return visit;
	}

	private Visit saveVisitDtl(VisitDTO visitDTO) throws DuplicateDataException {
		LOG.info("<<<LOG ENTRY>>" + VisitServiceImpl.class + "saveVisitDtl()");
		Visit visit = new Visit();
		if (visitRepository.findByVisitId(visitDTO.getVisit_id()) != null)
			throw new DuplicateDataException("Visit Already Exists");
		else {

			visit.setReason(visitDTO.getReason());
			visit.setVisitId(visitDTO.getVisit_id());
			visit.setVisit(visitDTO.getVisitDateTime());
			visitRepository.save(visit);
		}
		LOG.info("<<<LOG EXIT>>" + VisitServiceImpl.class + "saveVisitDtl()");
		return visit;
	}

	private void savePatientDtl(VisitDTO visitDTO) throws DuplicateDataException {
		LOG.info("<<<LOG ENTRY>>" + VisitServiceImpl.class + "savePatientDtl()");

		if (patientRepository.findByPatientId(visitDTO.getPatient_Id()) != null)
			throw new DuplicateDataException("Patient Already Exists");
		else {
			Patient patient = new Patient();
			patient.setGender(visitDTO.getPatient_Gender());
			patient.setAge(visitDTO.getPatient_Gender());
			patient.setName(visitDTO.getPatient_Name());
			patient.setCreated_By("APP");
			patient.setCreated_ts(ClinicCommonUtil.getcurrentTimestamp());
			patient.setModified_ts(ClinicCommonUtil.getcurrentTimestamp());
			patientRepository.save(patient);
		}
		LOG.info("<<<LOG EXIT>>" + VisitServiceImpl.class + "savePatientDtl()");

	}

	private void savePhysicianDtl(VisitDTO visitDTO) throws DuplicateDataException {
		LOG.info("<<<LOG ENTRY>>" + VisitServiceImpl.class + "savePhysicianDtl()");

		if (physicianRepository.findByPhysicianId(visitDTO.getPhysician_Id()) != null)
			throw new DuplicateDataException("Physician Already Exists");
		else {
			Physician physician = new Physician();
			physician.setName(visitDTO.getPhysican_name());
			physician.setPhysicianId(visitDTO.getPhysician_Id());
			physicianRepository.save(physician);
		}
		LOG.info("<<<LOG EXIT>>" + VisitServiceImpl.class + "savePhysicianDtl()");

	}

}
