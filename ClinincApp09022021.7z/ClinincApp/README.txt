database configuration
1.please put your configuration under application.properties file
2.build common and then domain and then service and rest
3.to create table in database run application make sure in property file you have metntioned
 #spring.jpa.hibernate.ddl-auto=create-drop
4.app-clinic-visit-rest and app-clinic-bill-rest these are two diffrent war files which provides 
Independent service so that if client doesnt want billin service then no need to deploye
5. using springboot 2.1.4
6. Created multimodule Application
7. As i've no database setup all i've created application without testing.
