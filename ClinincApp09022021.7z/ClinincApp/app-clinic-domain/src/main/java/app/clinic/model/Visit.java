package app.clinic.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "visit")
public class Visit implements Serializable{

	private static final long serialVersionUID = -8759266516063216054L;
	
	@Id
	@SequenceGenerator(name = "visit_seq", sequenceName = "visitid_seq", allocationSize = 1, initialValue = 100)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "visitid_seq")
	@Column(name = "visit_id")
	private long visitId;
	

	@Column(name = "visit")
	private Date visit;
	
	@Column(name = "physician")
	private String physician ;
	
	@Column(name = "reason")
	private String reason;
	
	@Column(name = "created_ts")
	private String created_Ts;

	@Column(name = "modified_ts")
	private Date modified_Ts;

	@Column(name = "created_by")
	private Date created_By;
	
	@Column(name = "modified_by")
	private String modified_By;

	public long getVisitId() {
		return visitId;
	}

	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}

	public Date getVisit() {
		return visit;
	}

	public void setVisit(Date visit) {
		this.visit = visit;
	}

	public String getPhysician() {
		return physician;
	}

	public void setPhysician(String physician) {
		this.physician = physician;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getCreated_Ts() {
		return created_Ts;
	}

	public void setCreated_Ts(String created_Ts) {
		this.created_Ts = created_Ts;
	}

	public Date getModified_Ts() {
		return modified_Ts;
	}

	public void setModified_Ts(Date modified_Ts) {
		this.modified_Ts = modified_Ts;
	}

	public Date getCreated_By() {
		return created_By;
	}

	public void setCreated_By(Date created_By) {
		this.created_By = created_By;
	}

	public String getModified_By() {
		return modified_By;
	}

	public void setModified_By(String modified_By) {
		this.modified_By = modified_By;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Visit()
	{}
	public Visit(long visitId, Date visit, String physician, String reason, String created_Ts, Date modified_Ts,
			Date created_By, String modified_By) {
		super();
		this.visitId = visitId;
		this.visit = visit;
		this.physician = physician;
		this.reason = reason;
		this.created_Ts = created_Ts;
		this.modified_Ts = modified_Ts;
		this.created_By = created_By;
		this.modified_By = modified_By;
	}

	@Override
	public String toString() {
		return "Visit [visitId=" + visitId + ", visit=" + visit + ", physician=" + physician + ", reason=" + reason
				+ ", created_Ts=" + created_Ts + ", modified_Ts=" + modified_Ts + ", created_By=" + created_By
				+ ", modified_By=" + modified_By + "]";
	}

}
