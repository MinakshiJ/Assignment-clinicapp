package app.clinic.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "holiday")
public class Holiday implements Serializable {

	private static final long serialVersionUID = -7541852901437142851L;

	@Id
	// @SequenceGenerator(name = "chatlog_cid_seq", sequenceName =
	// "chatlog_cid_seq", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "c_id", unique = true, nullable = false)
	private long cId;

	@Column(name = "name")
	private String name;

	@Column(name = "holiday")
	private Date holiday;

	@Column(name = "created_ts")
	private String created_Ts;

	@Column(name = "modified_ts")
	private Date modified_Ts;

	@Column(name = "created_by")
	private Date created_By;
	
	@Column(name = "modified_by")
	private String modified_By;

	public long getcId() {
		return cId;
	}

	public void setcId(long cId) {
		this.cId = cId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getHoliday() {
		return holiday;
	}

	public void setHoliday(Date holiday) {
		this.holiday = holiday;
	}

	public String getCreated_Ts() {
		return created_Ts;
	}

	public void setCreated_Ts(String created_Ts) {
		this.created_Ts = created_Ts;
	}

	public Date getModified_Ts() {
		return modified_Ts;
	}

	public void setModified_Ts(Date modified_Ts) {
		this.modified_Ts = modified_Ts;
	}

	public Date getCreated_By() {
		return created_By;
	}

	public void setCreated_By(Date created_By) {
		this.created_By = created_By;
	}

	public String getModified_By() {
		return modified_By;
	}

	public void setModified_By(String modified_By) {
		this.modified_By = modified_By;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	public Holiday()
	{}
	
	public Holiday(long cId, String name, Date holiday, String created_Ts, Date modified_Ts, Date created_By,
			String modified_By) {
		super();
		this.cId = cId;
		this.name = name;
		this.holiday = holiday;
		this.created_Ts = created_Ts;
		this.modified_Ts = modified_Ts;
		this.created_By = created_By;
		this.modified_By = modified_By;
	}

	@Override
	public String toString() {
		return "Holiday [cId=" + cId + ", name=" + name + ", holiday=" + holiday + ", created_Ts=" + created_Ts
				+ ", modified_Ts=" + modified_Ts + ", created_By=" + created_By + ", modified_By=" + modified_By + "]";
	}

}
