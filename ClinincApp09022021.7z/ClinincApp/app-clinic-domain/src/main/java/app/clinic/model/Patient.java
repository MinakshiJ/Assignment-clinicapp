package app.clinic.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "patient")
public class Patient implements Serializable {

	private static final long serialVersionUID = -1428442657965096226L;

	@Id
	@SequenceGenerator(name = "patientid_seq", sequenceName = "patientid_seq", allocationSize = 1, initialValue = 100)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "patientid_seq")
	@Column(name = "patient_id", unique = true, nullable = false)
	private long patientId;

	@Column(name = "name")
	private String name;

	@Column(name = "age")
	private String age;

	@Column(name = "gender")
	private String gender;

	@Column(name="created_ts")
	private Date created_ts;

	@Column(name = "modified_ts")
	private Date modified_ts;

	@Column(name = "created_By")
	private String created_By;

	public long getPatientId() {
		return patientId;
	}

	public void setPatientId(long patientId) {
		this.patientId = patientId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Date getCreated_ts() {
		return created_ts;
	}

	public void setCreated_ts(Date created_ts) {
		this.created_ts = created_ts;
	}

	public Date getModified_ts() {
		return modified_ts;
	}

	public void setModified_ts(Date modified_ts) {
		this.modified_ts = modified_ts;
	}

	public String getCreated_By() {
		return created_By;
	}

	public void setCreated_By(String created_By) {
		this.created_By = created_By;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Patient() {}

	public Patient(long patientId, String name, String age, String gender, Date created_ts, Date modified_ts,
			String created_By) {
		super();
		this.patientId = patientId;
		this.name = name;
		this.age = age;
		this.gender = gender;
		this.created_ts = created_ts;
		this.modified_ts = modified_ts;
		this.created_By = created_By;
	}
	@Override
	public String toString() {
		return "Patient [patientId=" + patientId + ", name=" + name + ", age=" + age + ", gender="
				+ gender +",created_ts"+created_ts +",modified_ts"+modified_ts+",created_By"+created_By+"]";
	}
	}