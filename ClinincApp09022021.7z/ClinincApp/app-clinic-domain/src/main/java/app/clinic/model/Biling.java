package app.clinic.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "T_BILING")
public class Biling implements Serializable {

	private static final long serialVersionUID = 8817094385360271329L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "BILING_ID", unique = true, nullable = false)
	private long biling_Id;
	/*uncomment if Relational Database
	 * @JsonIgnore
	 * 
	 * @ManyToOne(cascade = { CascadeType.MERGE, CascadeType.REFRESH}, fetch =
	 * FetchType.LAZY)
	 * 
	 * @JoinColumn(name = "patient_id") private Patient patient;
	 * 
	 * @JsonIgnore
	 * 
	 * @ManyToOne(cascade = { CascadeType.MERGE, CascadeType.REFRESH}, fetch =
	 * FetchType.LAZY)
	 * 
	 * @JoinColumn(name = "physician_id") private Physician physician ;
	 */
	@Column(name = "PATIENT_ID ")
	@Temporal(TemporalType.TIMESTAMP)
	private long patient_ID;

	@Column(name = "PHYSICIAN_ID ")
	@Temporal(TemporalType.TIMESTAMP)
	private long physicIan_ID;

	@Column(name = "BILLED_TS ")
	@Temporal(TemporalType.TIMESTAMP)
	private Date billedTs;

	public long getBiling_Id() {
		return biling_Id;
	}

	public void setBilling_Id(long biling_Id) {
		this.biling_Id = biling_Id;
	}

	/*
	 * public Patient getPatient() { return patient; }
	 * 
	 * public void setPatient(Patient patient) { this.patient = patient; }
	 * 
	 * public Physician getPhysician() { return physician; }
	 * 
	 * public void setPhysician(Physician physician) { this.physician = physician; }
	 * 
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public long getPatient_ID() {
		return patient_ID;
	}

	public void setPatient_ID(long patient_ID) {
		this.patient_ID = patient_ID;
	}

	public long getPhysicIan_ID() {
		return this.physicIan_ID;
	}

	public void setPhysicIan_ID(long physicIan_ID) {
		this.physicIan_ID = physicIan_ID;
	}

	public Date getBilledTs() {
		return billedTs;
	}

	public void setBilledTs(Date billedTs) {
		this.billedTs = billedTs;
	}

	@Override
	public String toString() {
		return "Biling [biling_Id=" + biling_Id + ", patient_ID=" + patient_ID + ", physicIan_ID=" + physicIan_ID
				+ ", billedTs=" + billedTs + "]";
	}
}
