
package app.clinic.repository;

import org.springframework.data.repository.CrudRepository;

import app.clinic.model.Patient;
import app.clinic.model.Visit;

public interface VisitRepository extends CrudRepository<Visit, Long> {
	
	public Visit findByVisitName(String visitname);
	Patient findByVisitId(long visitId);
	
}
