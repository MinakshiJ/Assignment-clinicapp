package app.clinic.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import app.clinic.model.Holiday;
import app.clinic.model.Physician;

@Repository
public interface PhysicianRepository extends CrudRepository<Physician, Long> {

	List<Holiday> findByPhysician(Physician Physician);

	Physician findByPhysicianId(long physicianID);

}
