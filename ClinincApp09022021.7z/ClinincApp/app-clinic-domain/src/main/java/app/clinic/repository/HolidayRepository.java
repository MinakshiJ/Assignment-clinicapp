package app.clinic.repository;

import java.util.Date;

import org.springframework.data.repository.CrudRepository;

import app.clinic.model.Holiday;

public interface HolidayRepository extends CrudRepository<Holiday, Long> {

	@Override
	Holiday save(Holiday holiday);

	Holiday findAllByHoliday(Date holiday);

}
