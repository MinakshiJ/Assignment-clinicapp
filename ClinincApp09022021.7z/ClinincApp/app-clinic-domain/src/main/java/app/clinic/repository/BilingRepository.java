package app.clinic.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import app.clinic.model.Biling;

@Repository
public interface BilingRepository extends CrudRepository<BilingRepository, Long> {

	@SuppressWarnings("unchecked")
	Biling save(Biling Biling);

}
