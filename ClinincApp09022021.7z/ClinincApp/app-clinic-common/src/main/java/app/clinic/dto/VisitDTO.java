package app.clinic.dto;

import java.util.Date;

public class VisitDTO {

	long patient_Id;
	String patient_Name;
	Integer patient_Age;
	String patient_Gender;

	long physician_Id;
	String physican_name;
	
	long visit_id;
	Date visitDateTime;
	String reason;

	public long getPatient_Id() {
		return patient_Id;
	}

	public void setPatient_Id(long patient_Id) {
		this.patient_Id = patient_Id;
	}

	public long getVisit_id() {
		return visit_id;
	}

	public void setVisit_id(long visit_id) {
		this.visit_id = visit_id;
	}

	public long getPhysician_Id() {
		return physician_Id;
	}

	public void setPhysician_Id(long physician_Id) {
		this.physician_Id = physician_Id;
	}

	public String getPatient_Name() {
		return patient_Name;
	}

	public void setPatient_Name(String patient_Name) {
		this.patient_Name = patient_Name;
	}

	public Integer getPatient_Age() {
		return patient_Age;
	}

	public void setPatient_Age(Integer patient_Age) {
		this.patient_Age = patient_Age;
	}

	public String getPatient_Gender() {
		return patient_Gender;
	}

	public void setPatient_Gender(String patient_Gender) {
		this.patient_Gender = patient_Gender;
	}

	public String getPhysican_name() {
		return physican_name;
	}

	public void setPhysican_name(String physican_name) {
		this.physican_name = physican_name;
	}

	public Date getVisitDateTime() {
		return visitDateTime;
	}

	public void setVisitDateTime(Date visitDateTime) {
		this.visitDateTime = visitDateTime;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

}
