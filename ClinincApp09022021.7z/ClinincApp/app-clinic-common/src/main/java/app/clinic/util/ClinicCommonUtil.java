package app.clinic.util;

import java.util.Date;

public class ClinicCommonUtil {

	public static Date getcurrentTimestamp() {
	
    return java.util.Calendar.getInstance().getTime();
}
}
