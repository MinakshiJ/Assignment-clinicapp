package app.clinic.dto;

public class BillingDTO {
	
	long PatiendId;
	long physicianId;
	public long getPatiendId() {
		return PatiendId;
	}
	public void setPatiendId(long patiendId) {
		PatiendId = patiendId;
	}
	public long getPhysicianId() {
		return physicianId;
	}
	public void setPhysicianId(long physicianId) {
		this.physicianId = physicianId;
	}
	@Override
	public String toString() {
		return "BillingDTO [PatiendId=" + PatiendId + ", physicianId=" + physicianId + "]";
	}
}
