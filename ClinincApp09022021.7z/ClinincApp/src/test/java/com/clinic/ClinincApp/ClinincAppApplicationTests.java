package com.clinic.ClinincApp;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClinincAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
